*****Landing Page Project*****

- Main functionality-> It's a website page which demonstarat the dynamic behavior of highliting the viewed section and dynamicly created table of content based on sections number.

- Files structure-> index.html (Holds the wbsite static structure and view)
                 -> styles.css (Holds the website styles)
                 -> app.js     (Holds the website logic handling and contoling the DOM)

- Features -> Dynamicly created contents of the sections based on its numbers.
           -> Each elemnt of table of content can view its reffered section when clicked.
           -> When the section is visible a highlight is activated in the background and in the table of content.
           -> All features are usable across modern desktop, tablet, and phone browsers.

